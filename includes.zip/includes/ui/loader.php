<div id="pageLoader" class="page-loader">
  <div class="loader-circle-37">
    <img src="assets/img/logoMSI.png" class="loader-logo" alt="Logo MSI">
  </div>
</div>
